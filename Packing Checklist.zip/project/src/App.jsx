import { useState } from 'react'
import './App.css'

function App() {
  const [items, setItems] = useState({
    essentials: [
      { id: 1, name: 'Passport', checked: false },
      { id: 2, name: 'Phone Charger', checked: false },
      { id: 3, name: 'Wallet', checked: false },
      { id: 4, name: 'Travel Insurance', checked: false }
    ],
    clothing: [
      { id: 5, name: 'T-shirts', checked: false },
      { id: 6, name: 'Pants', checked: false },
      { id: 7, name: 'Socks', checked: false },
      { id: 8, name: 'Underwear', checked: false },
      { id: 9, name: 'Jacket', checked: false }
    ],
    toiletries: [
      { id: 10, name: 'Toothbrush', checked: false },
      { id: 11, name: 'Toothpaste', checked: false },
      { id: 12, name: 'Shampoo', checked: false },
      { id: 13, name: 'Deodorant', checked: false },
      { id: 14, name: 'Sunscreen', checked: false }
    ]
  })

  const toggleItem = (category, id) => {
    setItems(prev => ({
      ...prev,
      [category]: prev[category].map(item => 
        item.id === id ? { ...item, checked: !item.checked } : item
      )
    }))
  }

  const resetChecklist = () => {
    setItems(prev => {
      const reset = {}
      Object.entries(prev).forEach(([category, items]) => {
        reset[category] = items.map(item => ({ ...item, checked: false }))
      })
      return reset
    })
  }

  return (
    <div className="checklist-container">
      <h1>Packing Checklist</h1>
      {Object.entries(items).map(([category, categoryItems]) => (
        <div key={category} className="category">
          <h2>{category.charAt(0).toUpperCase() + category.slice(1)}</h2>
          <ul>
            {categoryItems.map(item => (
              <li key={item.id}>
                <label className="checkbox-label">
                  <input
                    type="checkbox"
                    checked={item.checked}
                    onChange={() => toggleItem(category, item.id)}
                  />
                  <span className={item.checked ? 'checked' : ''}>
                    {item.name}
                  </span>
                </label>
              </li>
            ))}
          </ul>
        </div>
      ))}
      <button onClick={resetChecklist} className="reset-button">
        Reset All
      </button>
    </div>
  )
}

export default App